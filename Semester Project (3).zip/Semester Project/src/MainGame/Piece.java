package MainGame;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.imageio.ImageIO;
 
public class Piece {
 
    public enum Side {
        WHITE, BLACK;
 
        public Side opposite() {
            return this == WHITE ? BLACK : WHITE;
        }
    }
 
    public enum Type {
        KING('K', '\u265A'),
        QUEEN('Q', '\u265B'),
        ROOK('R', '\u265C'),
        BISHOP('B', '\u265D'),
        KNIGHT('N', '\u265E'),
        PAWN('P', '\u265F');
 
        private final char code;
        private final char glyph;
 
        Type(char code, char glyph) {
            this.code = code;
            this.glyph = glyph;
        }
 
        public char getCode() {
            return code;
        }
 
        public char getGlyph() {
            return glyph;
        }
    }
 
    private static final String RESOURCE_FOLDER = "/images/";
    private static final String[] FILE_FOLDERS = {"images/", "src/images/"};
 
    private static final Map<String, BufferedImage> SOURCE_IMAGES = new HashMap<>();
    private static final Map<String, BufferedImage> SCALED_IMAGES = new HashMap<>();
    private static int scaledCacheSize = -1;
 
    private final Type type;
    private final Side side;
    private boolean hasMoved = false;
 
    public Piece(Type type, Side side) {
        if (type == null || side == null) {
            throw new IllegalArgumentException("Piece type and side are required");
        }
        this.type = type;
        this.side = side;
    }
 
    public Type getType() {
        return type;
    }
 
    public Side getSide() {
        return side;
    }
 
    public boolean isWhite() {
        return side == Side.WHITE;
    }
 
    public boolean hasMoved() {
        return hasMoved;
    }
 
    public void markMoved() {
        hasMoved = true;
    }
 
    public boolean isEnemyOf(Piece other) {
        return other != null && other.side != side;
    }
 
    // Movement is decided by Rules; the piece only asks
    public List<int[]> getValidMoves(Board board, int row, int col) {
        return Rules.getValidMoves(board, row, col);
    }
 
    public boolean canMoveTo(Board board, int fromRow, int fromCol, int toRow, int toCol) {
        return Rules.isValidMove(board, fromRow, fromCol, toRow, toCol);
    }
 
    public String getImageFileName() {
        return (isWhite() ? "w" : "b") + type.getCode() + ".png";
    }
 
    public void draw(Graphics2D g, int x, int y, int squareSize) {
        int padding = Math.round(squareSize * 0.06f);
        int drawSize = squareSize - 2 * padding;
        BufferedImage image = getScaledImage(getImageFileName(), drawSize);
 
        if (image != null) {
            int imageX = x + (squareSize - image.getWidth()) / 2;
            int imageY = y + (squareSize - image.getHeight()) / 2;
            g.drawImage(image, imageX, imageY, null);
        } 
        
    }
 
    private static BufferedImage getScaledImage(String fileName, int size) {
        if (size <= 0) {
            return null;
        }
        // Window resizing produces many sizes; keep only the current one
        if (size != scaledCacheSize) {
            SCALED_IMAGES.clear();
            scaledCacheSize = size;
        }
        if (SCALED_IMAGES.containsKey(fileName)) {
            return SCALED_IMAGES.get(fileName);
        }
        BufferedImage source = loadSourceImage(fileName);
        BufferedImage scaled = source == null ? null : scaleToFit(source, size);
        SCALED_IMAGES.put(fileName, scaled);
        return scaled;
    }
 
    private static BufferedImage loadSourceImage(String fileName) {
        if (SOURCE_IMAGES.containsKey(fileName)) {
            return SOURCE_IMAGES.get(fileName);
        }
        BufferedImage image = null;
        try {
            URL resource = Piece.class.getResource(RESOURCE_FOLDER + fileName);
            if (resource != null) {
                image = ImageIO.read(resource);
            } else {
                for (String folder : FILE_FOLDERS) {
                    File file = new File(folder + fileName);
                    if (file.isFile()) {
                        image = ImageIO.read(file);
                        break;
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Could not read piece image " + fileName + ": " + e.getMessage());
        }
        if (image == null) {
            System.err.println("Piece image not found: " + fileName + " (using fallback drawing)");
        }
        SOURCE_IMAGES.put(fileName, image);
        return image;
    }
 
    // Halves the image step by step; a single big downscale looks jagged
    private static BufferedImage scaleToFit(BufferedImage source, int size) {
        double ratio = Math.min((double) size / source.getWidth(), (double) size / source.getHeight());
        int targetWidth = Math.max(1, (int) Math.round(source.getWidth() * ratio));
        int targetHeight = Math.max(1, (int) Math.round(source.getHeight() * ratio));
 
        BufferedImage current = source;
        int width = source.getWidth();
        int height = source.getHeight();
        do {
            width = (width / 2 >= targetWidth) ? width / 2 : targetWidth;
            height = (height / 2 >= targetHeight) ? height / 2 : targetHeight;
            current = resize(current, width, height);
        } while (width != targetWidth || height != targetHeight);
        return current;
    }
 
    private static BufferedImage resize(BufferedImage source, int width, int height) {
        BufferedImage result = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = result.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.drawImage(source, 0, 0, width, height, null);
        } finally {
            g.dispose();
        }
        return result;
    }
 
    @Override
    public String toString() {
        return side + " " + type;
    }
}
