package MainGame;
import java.util.ArrayList;
import java.util.List;
 
public final class Rules {
 
    private static final int[][] KNIGHT_OFFSETS = {
        {-2, -1}, {-2, 1}, {-1, -2}, {-1, 2}, {1, -2}, {1, 2}, {2, -1}, {2, 1}
    };
    private static final int[][] KING_OFFSETS = {
        {-1, -1}, {-1, 0}, {-1, 1}, {0, -1}, {0, 1}, {1, -1}, {1, 0}, {1, 1}
    };
    private static final int[][] STRAIGHT_DIRECTIONS = {
        {-1, 0}, {1, 0}, {0, -1}, {0, 1}
    };
    private static final int[][] DIAGONAL_DIRECTIONS = {
        {-1, -1}, {-1, 1}, {1, -1}, {1, 1}
    };
 
    private static final int WHITE_PAWN_START_ROW = 6;
    private static final int BLACK_PAWN_START_ROW = 1;
 
    private Rules() {
    }
 
    public static List<int[]> getValidMoves(Board board, int row, int col) {
        List<int[]> moves = new ArrayList<>();
        Piece piece = board.getPiece(row, col);
        if (piece == null) {
            return moves;
        }
 
        switch (piece.getType()) {
            case PAWN:
                addPawnMoves(board, piece, row, col, moves);
                break;
            case KNIGHT:
                addStepMoves(board, piece, row, col, KNIGHT_OFFSETS, moves);
                break;
            case BISHOP:
                addSlidingMoves(board, piece, row, col, DIAGONAL_DIRECTIONS, moves);
                break;
            case ROOK:
                addSlidingMoves(board, piece, row, col, STRAIGHT_DIRECTIONS, moves);
                break;
            case QUEEN:
                addSlidingMoves(board, piece, row, col, STRAIGHT_DIRECTIONS, moves);
                addSlidingMoves(board, piece, row, col, DIAGONAL_DIRECTIONS, moves);
                break;
            case KING:
                addStepMoves(board, piece, row, col, KING_OFFSETS, moves);
                break;
            default:
                throw new IllegalStateException("Unknown piece type: " + piece.getType());
        }
        return moves;
    }
 
    public static boolean isValidMove(Board board, int fromRow, int fromCol, int toRow, int toCol) {
        for (int[] target : getValidMoves(board, fromRow, fromCol)) {
            if (target[0] == toRow && target[1] == toCol) {
                return true;
            }
        }
        return false;
    }
 
    private static void addPawnMoves(Board board, Piece pawn, int row, int col, List<int[]> moves) {
        int direction = pawn.isWhite() ? -1 : 1;
        int startRow = pawn.isWhite() ? WHITE_PAWN_START_ROW : BLACK_PAWN_START_ROW;
        int oneStepRow = row + direction;
 
        if (board.isEmpty(oneStepRow, col)) {
            moves.add(new int[]{oneStepRow, col});
            int twoStepRow = row + 2 * direction;
            if (row == startRow && board.isEmpty(twoStepRow, col)) {
                moves.add(new int[]{twoStepRow, col});
            }
        }
 
        for (int sideStep : new int[]{-1, 1}) {
            Piece target = board.getPiece(oneStepRow, col + sideStep);
            if (pawn.isEnemyOf(target)) {
                moves.add(new int[]{oneStepRow, col + sideStep});
            }
        }
    }
 
    // Knight and king: fixed jumps, blocked only by own pieces
    private static void addStepMoves(Board board, Piece piece, int row, int col,
                                     int[][] offsets, List<int[]> moves) {
        for (int[] offset : offsets) {
            int targetRow = row + offset[0];
            int targetCol = col + offset[1];
            if (isEmptyOrEnemy(board, piece, targetRow, targetCol)) {
                moves.add(new int[]{targetRow, targetCol});
            }
        }
    }
 
    // Bishop, rook, queen: travel until the edge, a blocker, or a capture
    private static void addSlidingMoves(Board board, Piece piece, int row, int col,
                                        int[][] directions, List<int[]> moves) {
        for (int[] direction : directions) {
            int targetRow = row + direction[0];
            int targetCol = col + direction[1];
            while (board.isInside(targetRow, targetCol)) {
                Piece occupant = board.getPiece(targetRow, targetCol);
                if (occupant == null) {
                    moves.add(new int[]{targetRow, targetCol});
                } else {
                    if (piece.isEnemyOf(occupant)) {
                        moves.add(new int[]{targetRow, targetCol});
                    }
                    break;
                }
                targetRow += direction[0];
                targetCol += direction[1];
            }
        }
    }
 
    private static boolean isEmptyOrEnemy(Board board, Piece piece, int row, int col) {
        if (!board.isInside(row, col)) {
            return false;
        }
        Piece occupant = board.getPiece(row, col);
        return occupant == null || piece.isEnemyOf(occupant);
    }
}
