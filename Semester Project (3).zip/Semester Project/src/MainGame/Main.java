package MainGame;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Chess");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setContentPane(new Board());
            frame.pack();
            frame.setMinimumSize(new Dimension(420, 420));
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
