
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

public class UserStore {

    public boolean userExists(String username) {
        String sql = "SELECT id FROM login WHERE username = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username.toLowerCase());

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }

        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
            return false;
        }
    }

    public boolean register(String username, String password) {

        String salt = newSalt();
        String passwordHash = hash(password, salt);

        String sql = "INSERT INTO login "
        + "(username, salt, password_hash) VALUES (?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username.toLowerCase());
            ps.setString(2, salt);
            ps.setString(3, passwordHash);

            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            System.out.println("Could not register: " + e.getMessage());
            return false;
        }
    }

    public boolean checkPassword(String username, String password) {

        String sql = "SELECT salt, password_hash "
        + "FROM login WHERE username = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username.toLowerCase());

            try (ResultSet rs = ps.executeQuery()) {

                if (!rs.next()) {
                    return false;
                }

                String salt = rs.getString("salt");
                String savedHash = rs.getString("password_hash");
                String enteredHash = hash(password, salt);

                return MessageDigest.isEqual(
                        enteredHash.getBytes(StandardCharsets.UTF_8),
                        savedHash.getBytes(StandardCharsets.UTF_8)
                );
            }

        } catch (SQLException e) {
            System.out.println("Login database error: "
                    + e.getMessage());
            return false;
        }
    }

    private String newSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);

        return Base64.getEncoder().encodeToString(salt);
    }

    private String hash(String password, String salt) {

        try {
            byte[] saltBytes = Base64.getDecoder().decode(salt);

            PBEKeySpec spec = new PBEKeySpec(
                    password.toCharArray(),
                    saltBytes,
                    65536,
                    256
            );

            try {
                SecretKeyFactory factory =
                        SecretKeyFactory.getInstance(
                                "PBKDF2WithHmacSHA256"
                        );

                byte[] hashBytes =
                        factory.generateSecret(spec).getEncoded();

                return Base64.getEncoder()
                        .encodeToString(hashBytes);

            } finally {
                spec.clearPassword();
            }

        } catch (Exception e) {
            throw new RuntimeException(
                    "Password hashing failed", e
            );
        }
    }
}
