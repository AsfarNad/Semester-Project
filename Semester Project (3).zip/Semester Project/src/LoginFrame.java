import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
public class LoginFrame implements ActionListener {
 
    private final JFrame frame = new JFrame("Login");
    private final JTextField userField = new JTextField();
    private final JPasswordField passField = new JPasswordField();
    private final JButton loginButton = new JButton("Login");
    private final JButton resetButton = new JButton("Reset");
    private final JButton signUpButton = new JButton("Create account");
    private final JLabel messageLabel = new JLabel("", SwingConstants.CENTER);
    private final UserStore store;
 
    public LoginFrame(UserStore store) {
        this.store = store;
 
        JLabel userLabel = new JLabel("Username:");
        JLabel passLabel = new JLabel("Password:");
 
        userLabel.setBounds(50, 50, 80, 25);
        passLabel.setBounds(50, 95, 80, 25);
        userField.setBounds(140, 50, 180, 25);
        passField.setBounds(140, 95, 180, 25);
        loginButton.setBounds(140, 145, 85, 28);
        resetButton.setBounds(235, 145, 85, 28);
        signUpButton.setBounds(140, 185, 180, 28);
        messageLabel.setBounds(40, 230, 300, 30);
        messageLabel.setFont(new Font("SansSerif", Font.BOLD, 13));
 
        loginButton.setFocusable(false);
        resetButton.setFocusable(false);
        signUpButton.setFocusable(false);
        loginButton.addActionListener(this);
        resetButton.addActionListener(this);
        signUpButton.addActionListener(this);
        passField.addActionListener(this); // press Enter to log in
 
        frame.add(userLabel);
        frame.add(passLabel);
        frame.add(userField);
        frame.add(passField);
        frame.add(loginButton);
        frame.add(resetButton);
        frame.add(signUpButton);
        frame.add(messageLabel);
 
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(380, 360);
        frame.setLayout(null);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
 
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == resetButton) {
            userField.setText("");
            passField.setText("");
            messageLabel.setText("");
            return;
        }
 
        if (e.getSource() == signUpButton) {
            frame.dispose();
            new SignUpFrame(store);
            return;
        }
 
        // Login button or Enter key in the password field
        String username = userField.getText().trim();
        String password = new String(passField.getPassword());
 
        if (username.isEmpty() || password.isEmpty()) {
            showError("Please fill in both fields");
        } else if (!store.userExists(username)) {
            showError("Username not found");
        } else if (!store.checkPassword(username, password)) {
            showError("Wrong password");
        } else {
            frame.dispose();
            new HomeFrame(username);
        }
    }
 
    private void showError(String text) {
        messageLabel.setForeground(Color.RED);
        messageLabel.setText(text);
    }
}
