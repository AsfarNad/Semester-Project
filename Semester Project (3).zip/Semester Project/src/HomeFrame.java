import javax.swing.*;
import java.awt.*;
 
public class HomeFrame {
 
    private final JFrame frame = new JFrame("Home");
 
    public HomeFrame(String username) {
        JLabel welcome = new JLabel("Welcome, " + username + "!", SwingConstants.CENTER);
        welcome.setFont(new Font("SansSerif", Font.PLAIN, 24));
 
        frame.add(welcome);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
