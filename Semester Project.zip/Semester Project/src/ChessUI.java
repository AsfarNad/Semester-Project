import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

public final class ChessUI {

    static final Color GREEN = new Color(0x769656);
    static final Color CREAM = new Color(0xEEEED2);
    static final Color INK   = new Color(0x262421);
    static final Color GOLD  = new Color(0xE8C170);
    static final Color ERROR = new Color(0xE5736B);

    static final String BACK_RANK = "♜ ♞ ♝ ♛ ♚ ♝ ♞ ♜";
    static final String PAWNS     = "♙ ♙ ♙ ♙ ♙ ♙ ♙ ♙";

    private static final Color INK_TOP    = new Color(0x34312D);
    private static final Color GOLD_SOFT  = new Color(0xE8, 0xC1, 0x70, 90);
    private static final Color CREAM_SOFT = new Color(0xEE, 0xEE, 0xD2, 110);
    private static final Color WATERMARK  = new Color(0xEE, 0xEE, 0xD2, 14);
    private static final Color SHADOW     = new Color(0, 0, 0, 90);
    private static final int CARD_INSET = 18;

    private ChessUI() {}

    /** w and h are the usable content size; window decorations are added on top. */
    static JFrame frame(String title, int w, int h) {
        JFrame f = new JFrame(title);
        Board board = new Board();
        board.setLayout(null);
        board.setPreferredSize(new Dimension(w, h));
        f.setContentPane(board);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(false); // must come before pack() or Windows adds extra insets
        f.pack();
        f.setLocationRelativeTo(null);
        return f;
    }

    static void add(JFrame f, Component... parts) {
        for (Component c : parts) f.add(c);
    }

    static JLabel title(String text, int width) {
        JLabel l = new JLabel(text, SwingConstants.CENTER);
        l.setFont(new Font("SansSerif", Font.BOLD, 28));
        l.setForeground(GOLD);
        l.setBounds(0, 40, width, 44);
        return l;
    }

    static JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("SansSerif", Font.PLAIN, 13));
        l.setForeground(CREAM);
        return l;
    }

    /** Row of chess glyphs flanked by thin gold rules. */
    static JComponent ornament(String glyphs, boolean bright, int width, int y) {
        JComponent row = new JComponent() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setFont(new Font("SansSerif", Font.PLAIN, 17));

                FontMetrics fm = g2.getFontMetrics();
                int textW = fm.stringWidth(glyphs);
                int textX = (getWidth() - textW) / 2;
                int midY = getHeight() / 2;
                int margin = 70;
                int gap = 12;

                g2.setColor(GOLD_SOFT);
                g2.drawLine(margin, midY, textX - gap, midY);
                g2.drawLine(textX + textW + gap, midY, getWidth() - margin, midY);

                g2.setColor(bright ? GOLD : CREAM_SOFT);
                g2.drawString(glyphs, textX, midY + (fm.getAscent() - fm.getDescent()) / 2);
                g2.dispose();
            }
        };
        row.setBounds(0, y, width, 24);
        return row;
    }

    static void style(JTextField f) {
        Border idle = fieldBorder(GREEN);
        Border focused = fieldBorder(GOLD);
        f.setBackground(CREAM);
        f.setForeground(INK);
        f.setCaretColor(INK);
        f.setFont(new Font("SansSerif", Font.PLAIN, 14));
        f.setBorder(idle);
        f.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) { f.setBorder(focused); }
            @Override public void focusLost(FocusEvent e)   { f.setBorder(idle); }
        });
    }

    private static Border fieldBorder(Color line) {
        return new CompoundBorder(new LineBorder(line, 2), new EmptyBorder(0, 8, 0, 8));
    }

    static void style(JButton b, boolean primary) {
        Color base = primary ? GREEN : new Color(0x3A3835);
        b.setBackground(base);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("SansSerif", Font.BOLD, 13));
        b.setOpaque(true);
        b.setBorderPainted(false);
        b.setFocusable(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { b.setBackground(base.brighter()); }
            @Override public void mouseExited(MouseEvent e)  { b.setBackground(base); }
        });
    }

    /** Checkerboard background with a framed dark card and a knight watermark. */
    private static class Board extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();

            int s = 47;
            for (int r = 0; r * s < h; r++) {
                for (int c = 0; c * s < w; c++) {
                    g2.setColor((r + c) % 2 == 0 ? CREAM : GREEN);
                    g2.fillRect(c * s, r * s, s, s);
                }
            }

            int cw = w - CARD_INSET * 2;
            int ch = h - CARD_INSET * 2;
            Shape card = new RoundRectangle2D.Float(CARD_INSET, CARD_INSET, cw, ch, 24, 24);

            g2.setColor(SHADOW);
            g2.fill(new RoundRectangle2D.Float(CARD_INSET + 3, CARD_INSET + 6, cw, ch, 24, 24));

            g2.setPaint(new GradientPaint(0, CARD_INSET, INK_TOP, 0, CARD_INSET + ch, INK));
            g2.fill(card);

            paintWatermark(g2, card, w, h);

            g2.setColor(GOLD);
            g2.setStroke(new BasicStroke(2));
            g2.draw(card);

            g2.setColor(GOLD_SOFT);
            g2.setStroke(new BasicStroke(1));
            g2.draw(new RoundRectangle2D.Float(CARD_INSET + 6, CARD_INSET + 6, cw - 12, ch - 12, 18, 18));

            g2.dispose();
        }

        private void paintWatermark(Graphics2D g2, Shape card, int w, int h) {
            Shape oldClip = g2.getClip();
            g2.clip(card);
            int size = (int) (Math.min(w, h) * 0.75);
            g2.setFont(new Font("SansSerif", Font.PLAIN, size));
            FontMetrics fm = g2.getFontMetrics();
            g2.setColor(WATERMARK);
            // Bottom-right, partly bleeding off the card
            g2.drawString("♞", w - fm.stringWidth("♞") + size / 8, h - CARD_INSET + fm.getDescent() / 2);
            g2.setClip(oldClip);
        }
    }
}