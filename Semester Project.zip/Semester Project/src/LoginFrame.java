import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginFrame implements ActionListener {

    private static final int WIDTH = 440;

    private final JFrame frame = ChessUI.frame("Login", WIDTH, 460);
    private final JTextField userField = new JTextField();
    private final JPasswordField passField = new JPasswordField();
    private final JButton loginButton = new JButton("Login");
    private final JButton resetButton = new JButton("Reset");
    private final JButton signUpButton = new JButton("Create account");
    private final JLabel messageLabel = new JLabel("", SwingConstants.CENTER);
    private final UserStore store;

    public LoginFrame(UserStore store) {
        this.store = store;

        JLabel title = ChessUI.title("♚  Chess Login", WIDTH);
        JComponent backRank = ChessUI.ornament(ChessUI.BACK_RANK, true, WIDTH, 88);
        JComponent pawns = ChessUI.ornament(ChessUI.PAWNS, false, WIDTH, 398);

        JLabel userLabel = ChessUI.label("Username");
        JLabel passLabel = ChessUI.label("Password");

        userLabel.setBounds(70, 124, 300, 20);
        userField.setBounds(70, 146, 300, 36);
        passLabel.setBounds(70, 192, 300, 20);
        passField.setBounds(70, 214, 300, 36);
        loginButton.setBounds(70, 268, 145, 38);
        resetButton.setBounds(225, 268, 145, 38);
        signUpButton.setBounds(70, 316, 300, 38);
        messageLabel.setBounds(30, 364, 380, 24);
        messageLabel.setFont(new Font("SansSerif", Font.BOLD, 13));

        ChessUI.style(userField);
        ChessUI.style(passField);
        ChessUI.style(loginButton, true);
        ChessUI.style(resetButton, false);
        ChessUI.style(signUpButton, false);

        loginButton.addActionListener(this);
        resetButton.addActionListener(this);
        signUpButton.addActionListener(this);
        passField.addActionListener(this); // press Enter to log in

        ChessUI.add(frame, title, backRank, userLabel, userField,
                passLabel, passField, loginButton, resetButton, signUpButton, messageLabel, pawns);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == resetButton) {
            userField.setText("");
            passField.setText("");
            messageLabel.setText("");
            return;
        }

        if (e.getSource() == signUpButton) {
            frame.dispose();
            new SignUpFrame(store);
            return;
        }

        // Login button or Enter key in the password field
        String username = userField.getText().trim();
        String password = new String(passField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            showError("Please fill in both fields");
        } else if (!store.userExists(username)) {
            showError("Username not found");
        } else if (!store.checkPassword(username, password)) {
            showError("Wrong password");
        } else {
            frame.dispose();
            new HomeFrame(username, store);
        }
    }

    private void showError(String text) {
        messageLabel.setForeground(ChessUI.ERROR);
        messageLabel.setText(text);
    }
}