import MainGame.Main;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class HomeFrame implements ActionListener {

    private final JFrame frame = ChessUI.frame("Home", 420, 220);
    private final JButton playButton = new JButton("Play");
    private final JButton logoutButton = new JButton("Logout");
    private final String username;
    private final UserStore store;

    public HomeFrame(String username, UserStore store) {
        this.username = username;
        this.store = store;

        JLabel welcome = ChessUI.title("♞  Welcome, " + username + "!", 420);
        welcome.setBounds(0, 50, 420, 40);

        JLabel sub = ChessUI.label("Your move awaits.");
        sub.setHorizontalAlignment(SwingConstants.CENTER);
        sub.setBounds(0, 92, 420, 20);

        playButton.setBounds(80, 132, 125, 32);
        logoutButton.setBounds(215, 132, 125, 32);
        ChessUI.style(playButton, true);
        ChessUI.style(logoutButton, false);
        playButton.addActionListener(this);
        logoutButton.addActionListener(this);

        ChessUI.add(frame, welcome, sub, playButton, logoutButton);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == playButton) {
            startGame();
        } else if (e.getSource() == logoutButton) {
            frame.dispose();
            new LoginFrame(store);
        }
    }

    // Home hides while the board is open and comes back when the board closes
    private void startGame() {
        JFrame game = Main.openGame("Chess - " + username, JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(false);
        game.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                frame.setVisible(true);
            }
        });
    }
}
