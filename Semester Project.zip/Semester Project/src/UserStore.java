import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;

public class UserStore {

    public boolean userExists(String username) {
        return exists("SELECT id FROM login WHERE username = ?", username.toLowerCase());
    }

    public boolean emailExists(String email) {
        return exists("SELECT id FROM login WHERE email = ?", email.toLowerCase());
    }

    private boolean exists(String sql, String value) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, value);
            return ps.executeQuery().next();
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
            return false;
        }
    }

    public boolean register(String username, String email, String password) {
        byte[] saltBytes = new byte[16];
        new SecureRandom().nextBytes(saltBytes);
        String salt = Base64.getEncoder().encodeToString(saltBytes);

        String sql = "INSERT INTO login (username, email, salt, password_hash) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username.toLowerCase());
            ps.setString(2, email.toLowerCase());
            ps.setString(3, salt);
            ps.setString(4, hash(password, salt));
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            System.out.println("Could not register: " + e.getMessage());
            return false;
        }
    }

    // False for a wrong password and for a username that does not exist
    public boolean checkPassword(String username, String password) {
        String sql = "SELECT salt, password_hash FROM login WHERE username = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username.toLowerCase());
            ResultSet rs = ps.executeQuery();
            return rs.next()
                    && hash(password, rs.getString("salt")).equals(rs.getString("password_hash"));
        } catch (SQLException e) {
            System.out.println("Login database error: " + e.getMessage());
            return false;
        }
    }

    // Salted SHA-256: simple, and the plain password is never stored
    private String hash(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest((salt + password).getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is not available", e);
        }
    }
}
