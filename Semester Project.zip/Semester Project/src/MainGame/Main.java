package MainGame;

import javax.swing.JFrame;

public class Main {

    // Called by HomeFrame once a user has logged in
    public static JFrame openGame(String title, int closeOperation) {
        JFrame frame = new JFrame(title);
        frame.setDefaultCloseOperation(closeOperation);
        frame.setContentPane(new Board());
        frame.setResizable(false);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        return frame;
    }
}
