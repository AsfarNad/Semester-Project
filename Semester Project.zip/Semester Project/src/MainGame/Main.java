package MainGame;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class Main {

    // Standalone run, without the login screens
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> openGame("Chess", JFrame.EXIT_ON_CLOSE));
    }

    // Entry point used by HomeFrame once a user has logged in
    public static JFrame openGame(String title, int closeOperation) {
        JFrame frame = new JFrame(title);
        frame.setDefaultCloseOperation(closeOperation);
        frame.setContentPane(new Board());
        frame.pack();
        frame.setMinimumSize(new Dimension(420, 420));
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        return frame;
    }
}
