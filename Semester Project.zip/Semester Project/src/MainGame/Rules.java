package MainGame;
import java.util.ArrayList;
import java.util.List;

public final class Rules {

    public enum Status { ONGOING, CHECK, CHECKMATE, STALEMATE }

    private static final int[][] KNIGHT_OFFSETS = {
        {-2, -1}, {-2, 1}, {-1, -2}, {-1, 2}, {1, -2}, {1, 2}, {2, -1}, {2, 1}
    };
    private static final int[][] KING_OFFSETS = {
        {-1, -1}, {-1, 0}, {-1, 1}, {0, -1}, {0, 1}, {1, -1}, {1, 0}, {1, 1}
    };
    private static final int[][] STRAIGHT_DIRECTIONS = {
        {-1, 0}, {1, 0}, {0, -1}, {0, 1}
    };
    private static final int[][] DIAGONAL_DIRECTIONS = {
        {-1, -1}, {-1, 1}, {1, -1}, {1, 1}
    };

    private Rules() {
    }

    // Only moves that do not leave the mover's own king in check
    public static List<int[]> getValidMoves(Board board, int row, int col) {
        List<int[]> legal = new ArrayList<>();
        if (board.getPiece(row, col) == null) {
            return legal;
        }
        for (int[] target : getPseudoLegalMoves(board, row, col)) {
            if (!leavesKingInCheck(board, row, col, target[0], target[1])) {
                legal.add(target);
            }
        }
        return legal;
    }

    public static Status getStatus(Board board, Piece.Side sideToMove) {
        boolean inCheck = isInCheck(board, sideToMove);
        if (hasAnyLegalMove(board, sideToMove)) {
            return inCheck ? Status.CHECK : Status.ONGOING;
        }
        return inCheck ? Status.CHECKMATE : Status.STALEMATE;
    }

    public static boolean isInCheck(Board board, Piece.Side side) {
        int[] king = findKing(board, side);
        return isSquareAttacked(board, king[0], king[1], side.opposite());
    }

    // Looks outward from the square instead of generating every enemy move,
    // so castling checks cannot recurse back into move generation
    public static boolean isSquareAttacked(Board board, int row, int col, Piece.Side attacker) {
        // A white pawn attacks upward (row - 1), so it sits one row below the square
        int pawnRow = attacker == Piece.Side.WHITE ? row + 1 : row - 1;
        if (isPieceOf(board, pawnRow, col - 1, attacker, Piece.Type.PAWN)
                || isPieceOf(board, pawnRow, col + 1, attacker, Piece.Type.PAWN)) {
            return true;
        }
        for (int[] offset : KNIGHT_OFFSETS) {
            if (isPieceOf(board, row + offset[0], col + offset[1], attacker, Piece.Type.KNIGHT)) {
                return true;
            }
        }
        for (int[] offset : KING_OFFSETS) {
            if (isPieceOf(board, row + offset[0], col + offset[1], attacker, Piece.Type.KING)) {
                return true;
            }
        }
        return isAttackedAlongLines(board, row, col, attacker, STRAIGHT_DIRECTIONS, Piece.Type.ROOK)
                || isAttackedAlongLines(board, row, col, attacker, DIAGONAL_DIRECTIONS, Piece.Type.BISHOP);
    }

    // The queen attacks along both kinds of line, so it always counts
    private static boolean isAttackedAlongLines(Board board, int row, int col, Piece.Side attacker,
                                                int[][] directions, Piece.Type lineMover) {
        for (int[] direction : directions) {
            int r = row + direction[0];
            int c = col + direction[1];
            while (board.isEmpty(r, c)) {
                r += direction[0];
                c += direction[1];
            }
            if (isPieceOf(board, r, c, attacker, lineMover) || isPieceOf(board, r, c, attacker, Piece.Type.QUEEN)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isPieceOf(Board board, int row, int col, Piece.Side side, Piece.Type type) {
        Piece piece = board.getPiece(row, col);
        return piece != null && piece.getSide() == side && piece.getType() == type;
    }

    public static int[] findKing(Board board, Piece.Side side) {
        for (int row = 0; row < Board.SIZE; row++) {
            for (int col = 0; col < Board.SIZE; col++) {
                Piece piece = board.getPiece(row, col);
                if (piece != null && piece.getSide() == side && piece.getType() == Piece.Type.KING) {
                    return new int[]{row, col};
                }
            }
        }
        throw new IllegalStateException(side + " king is missing");
    }

    private static boolean hasAnyLegalMove(Board board, Piece.Side side) {
        for (int row = 0; row < Board.SIZE; row++) {
            for (int col = 0; col < Board.SIZE; col++) {
                Piece piece = board.getPiece(row, col);
                if (piece != null && piece.getSide() == side
                        && !getValidMoves(board, row, col).isEmpty()) {
                    return true;
                }
            }
        }
        return false;
    }

    // Every move the piece could make if its own king's safety were ignored
    private static List<int[]> getPseudoLegalMoves(Board board, int row, int col) {
        List<int[]> moves = new ArrayList<>();
        Piece piece = board.getPiece(row, col);
        switch (piece.getType()) {
            case PAWN:
                addPawnMoves(board, piece, row, col, moves);
                break;
            case KNIGHT:
                addStepMoves(board, piece, row, col, KNIGHT_OFFSETS, moves);
                break;
            case BISHOP:
                addSlidingMoves(board, piece, row, col, DIAGONAL_DIRECTIONS, moves);
                break;
            case ROOK:
                addSlidingMoves(board, piece, row, col, STRAIGHT_DIRECTIONS, moves);
                break;
            case QUEEN:
                addSlidingMoves(board, piece, row, col, STRAIGHT_DIRECTIONS, moves);
                addSlidingMoves(board, piece, row, col, DIAGONAL_DIRECTIONS, moves);
                break;
            case KING:
                addStepMoves(board, piece, row, col, KING_OFFSETS, moves);
                addCastlingMoves(board, piece, row, col, moves);
                break;
        }
        return moves;
    }

    private static void addPawnMoves(Board board, Piece pawn, int row, int col, List<int[]> moves) {
        int direction = pawn.isWhite() ? -1 : 1;
        int startRow = pawn.isWhite() ? 6 : 1;
        int oneStepRow = row + direction;

        if (board.isEmpty(oneStepRow, col)) {
            moves.add(new int[]{oneStepRow, col});
            int twoStepRow = row + 2 * direction;
            if (row == startRow && board.isEmpty(twoStepRow, col)) {
                moves.add(new int[]{twoStepRow, col});
            }
        }

        for (int sideStep : new int[]{-1, 1}) {
            if (pawn.isEnemyOf(board.getPiece(oneStepRow, col + sideStep))) {
                moves.add(new int[]{oneStepRow, col + sideStep});
            }
        }

        // En passant: the enemy pawn that just double-stepped sits beside us
        int[] passant = board.getEnPassantTarget();
        if (passant != null && passant[0] == oneStepRow && Math.abs(passant[1] - col) == 1
                && isPieceOf(board, row, passant[1], pawn.getSide().opposite(), Piece.Type.PAWN)) {
            moves.add(new int[]{passant[0], passant[1]});
        }
    }

    private static void addCastlingMoves(Board board, Piece king, int row, int col, List<int[]> moves) {
        int homeRow = king.isWhite() ? 7 : 0;
        if (king.hasMoved() || row != homeRow || col != 4
                || isSquareAttacked(board, row, col, king.getSide().opposite())) {
            return;
        }
        tryCastle(board, king, row, col, 7, moves); // kingside
        tryCastle(board, king, row, col, 0, moves); // queenside
    }

    private static void tryCastle(Board board, Piece king, int row, int kingCol, int rookCol, List<int[]> moves) {
        Piece rook = board.getPiece(row, rookCol);
        if (rook == null || rook.getType() != Piece.Type.ROOK
                || rook.getSide() != king.getSide() || rook.hasMoved()) {
            return;
        }
        int step = rookCol > kingCol ? 1 : -1;
        for (int c = kingCol + step; c != rookCol; c += step) {
            if (!board.isEmpty(row, c)) {
                return;
            }
        }
        // King may not pass through or land on an attacked square
        Piece.Side enemy = king.getSide().opposite();
        if (isSquareAttacked(board, row, kingCol + step, enemy)
                || isSquareAttacked(board, row, kingCol + 2 * step, enemy)) {
            return;
        }
        moves.add(new int[]{row, kingCol + 2 * step});
    }

    public static boolean isCastlingMove(Board board, int fromRow, int fromCol, int toRow, int toCol) {
        Piece piece = board.getPiece(fromRow, fromCol);
        return piece != null && piece.getType() == Piece.Type.KING
                && fromRow == toRow && Math.abs(toCol - fromCol) == 2;
    }

    // {rookFromCol, rookToCol}; the rook lands on the square the king passed over
    public static int[] getCastlingRookCols(int kingFromCol, int kingToCol) {
        int rookFromCol = kingToCol > kingFromCol ? 7 : 0;
        return new int[]{rookFromCol, (kingFromCol + kingToCol) / 2};
    }

    public static boolean isEnPassantMove(Board board, int fromRow, int fromCol, int toRow, int toCol) {
        Piece piece = board.getPiece(fromRow, fromCol);
        int[] target = board.getEnPassantTarget();
        return piece != null && piece.getType() == Piece.Type.PAWN
                && fromCol != toCol && board.isEmpty(toRow, toCol)
                && target != null && target[0] == toRow && target[1] == toCol;
    }

    // Knight and king: fixed jumps, blocked only by own pieces
    private static void addStepMoves(Board board, Piece piece, int row, int col,
                                     int[][] offsets, List<int[]> moves) {
        for (int[] offset : offsets) {
            int targetRow = row + offset[0];
            int targetCol = col + offset[1];
            if (board.isEmpty(targetRow, targetCol)
                    || piece.isEnemyOf(board.getPiece(targetRow, targetCol))) {
                moves.add(new int[]{targetRow, targetCol});
            }
        }
    }

    // Bishop, rook, queen: travel until the edge, a blocker, or a capture
    private static void addSlidingMoves(Board board, Piece piece, int row, int col,
                                        int[][] directions, List<int[]> moves) {
        for (int[] direction : directions) {
            int targetRow = row + direction[0];
            int targetCol = col + direction[1];
            while (board.isEmpty(targetRow, targetCol)) {
                moves.add(new int[]{targetRow, targetCol});
                targetRow += direction[0];
                targetCol += direction[1];
            }
            if (piece.isEnemyOf(board.getPiece(targetRow, targetCol))) {
                moves.add(new int[]{targetRow, targetCol});
            }
        }
    }

    // Plays the move on the real grid, tests the king, then restores it
    private static boolean leavesKingInCheck(Board board, int fromRow, int fromCol, int toRow, int toCol) {
        Piece moving = board.getPiece(fromRow, fromCol);
        Piece captured = board.getPiece(toRow, toCol);
        boolean enPassant = isEnPassantMove(board, fromRow, fromCol, toRow, toCol);
        Piece passantVictim = enPassant ? board.getPiece(fromRow, toCol) : null;

        board.put(toRow, toCol, moving);
        board.put(fromRow, fromCol, null);
        if (enPassant) {
            board.put(fromRow, toCol, null);
        }
        try {
            return isInCheck(board, moving.getSide());
        } finally {
            board.put(fromRow, fromCol, moving);
            board.put(toRow, toCol, captured);
            if (enPassant) {
                board.put(fromRow, toCol, passantVictim);
            }
        }
    }
}
