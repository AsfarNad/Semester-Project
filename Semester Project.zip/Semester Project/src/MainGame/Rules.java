package MainGame;
import java.util.ArrayList;
import java.util.List;

public final class Rules {

    public enum Status { ONGOING, CHECK, CHECKMATE, STALEMATE }

    private static final int[][] KNIGHT_OFFSETS = {
        {-2, -1}, {-2, 1}, {-1, -2}, {-1, 2}, {1, -2}, {1, 2}, {2, -1}, {2, 1}
    };
    private static final int[][] KING_OFFSETS = {
        {-1, -1}, {-1, 0}, {-1, 1}, {0, -1}, {0, 1}, {1, -1}, {1, 0}, {1, 1}
    };
    private static final int[][] STRAIGHT_DIRECTIONS = {
        {-1, 0}, {1, 0}, {0, -1}, {0, 1}
    };
    private static final int[][] DIAGONAL_DIRECTIONS = {
        {-1, -1}, {-1, 1}, {1, -1}, {1, 1}
    };

    private Rules() {
    }

    // Only moves that do not leave the mover's own king in check
    public static List<int[]> getValidMoves(Board board, int row, int col) {
        List<int[]> legal = new ArrayList<>();
        if (board.getPiece(row, col) == null) {
            return legal;
        }
        for (int[] target : getPseudoLegalMoves(board, row, col)) {
            if (!leavesKingInCheck(board, row, col, target[0], target[1])) {
                legal.add(target);
            }
        }
        return legal;
    }

    public static Status getStatus(Board board, Piece.Side sideToMove) {
        boolean inCheck = isInCheck(board, sideToMove);
        if (hasAnyLegalMove(board, sideToMove)) {
            return inCheck ? Status.CHECK : Status.ONGOING;
        }
        return inCheck ? Status.CHECKMATE : Status.STALEMATE;
    }

    // In check if any enemy piece could move onto the king's square
    public static boolean isInCheck(Board board, Piece.Side side) {
        int[] king = findKing(board, side);
        for (int row = 0; row < Board.SIZE; row++) {
            for (int col = 0; col < Board.SIZE; col++) {
                Piece piece = board.getPiece(row, col);
                if (piece == null || piece.getSide() == side) {
                    continue;
                }
                for (int[] target : getPseudoLegalMoves(board, row, col)) {
                    if (target[0] == king[0] && target[1] == king[1]) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static int[] findKing(Board board, Piece.Side side) {
        for (int row = 0; row < Board.SIZE; row++) {
            for (int col = 0; col < Board.SIZE; col++) {
                Piece piece = board.getPiece(row, col);
                if (piece != null && piece.getSide() == side && piece.getType() == Piece.Type.KING) {
                    return new int[]{row, col};
                }
            }
        }
        throw new IllegalStateException(side + " king is missing");
    }

    private static boolean hasAnyLegalMove(Board board, Piece.Side side) {
        for (int row = 0; row < Board.SIZE; row++) {
            for (int col = 0; col < Board.SIZE; col++) {
                Piece piece = board.getPiece(row, col);
                if (piece != null && piece.getSide() == side
                        && !getValidMoves(board, row, col).isEmpty()) {
                    return true;
                }
            }
        }
        return false;
    }

    // Every move the piece could make if its own king's safety were ignored
    private static List<int[]> getPseudoLegalMoves(Board board, int row, int col) {
        List<int[]> moves = new ArrayList<>();
        Piece piece = board.getPiece(row, col);
        switch (piece.getType()) {
            case PAWN:
                addPawnMoves(board, piece, row, col, moves);
                break;
            case KNIGHT:
                addStepMoves(board, piece, row, col, KNIGHT_OFFSETS, moves);
                break;
            case BISHOP:
                addSlidingMoves(board, piece, row, col, DIAGONAL_DIRECTIONS, moves);
                break;
            case ROOK:
                addSlidingMoves(board, piece, row, col, STRAIGHT_DIRECTIONS, moves);
                break;
            case QUEEN:
                addSlidingMoves(board, piece, row, col, STRAIGHT_DIRECTIONS, moves);
                addSlidingMoves(board, piece, row, col, DIAGONAL_DIRECTIONS, moves);
                break;
            case KING:
                addStepMoves(board, piece, row, col, KING_OFFSETS, moves);
                break;
        }
        return moves;
    }

    private static void addPawnMoves(Board board, Piece pawn, int row, int col, List<int[]> moves) {
        int direction = pawn.isWhite() ? -1 : 1;
        int startRow = pawn.isWhite() ? 6 : 1;
        int oneStepRow = row + direction;

        if (board.isEmpty(oneStepRow, col)) {
            moves.add(new int[]{oneStepRow, col});
            int twoStepRow = row + 2 * direction;
            if (row == startRow && board.isEmpty(twoStepRow, col)) {
                moves.add(new int[]{twoStepRow, col});
            }
        }

        for (int sideStep : new int[]{-1, 1}) {
            if (pawn.isEnemyOf(board.getPiece(oneStepRow, col + sideStep))) {
                moves.add(new int[]{oneStepRow, col + sideStep});
            }
        }
    }

    // Knight and king: fixed jumps, blocked only by own pieces
    private static void addStepMoves(Board board, Piece piece, int row, int col,
                                     int[][] offsets, List<int[]> moves) {
        for (int[] offset : offsets) {
            int targetRow = row + offset[0];
            int targetCol = col + offset[1];
            if (board.isEmpty(targetRow, targetCol)
                    || piece.isEnemyOf(board.getPiece(targetRow, targetCol))) {
                moves.add(new int[]{targetRow, targetCol});
            }
        }
    }

    // Bishop, rook, queen: travel until the edge, a blocker, or a capture
    private static void addSlidingMoves(Board board, Piece piece, int row, int col,
                                        int[][] directions, List<int[]> moves) {
        for (int[] direction : directions) {
            int targetRow = row + direction[0];
            int targetCol = col + direction[1];
            while (board.isEmpty(targetRow, targetCol)) {
                moves.add(new int[]{targetRow, targetCol});
                targetRow += direction[0];
                targetCol += direction[1];
            }
            if (piece.isEnemyOf(board.getPiece(targetRow, targetCol))) {
                moves.add(new int[]{targetRow, targetCol});
            }
        }
    }

    // Plays the move on the real grid, tests the king, then restores it
    private static boolean leavesKingInCheck(Board board, int fromRow, int fromCol, int toRow, int toCol) {
        Piece moving = board.getPiece(fromRow, fromCol);
        Piece captured = board.getPiece(toRow, toCol);
        board.put(toRow, toCol, moving);
        board.put(fromRow, fromCol, null);
        try {
            return isInCheck(board, moving.getSide());
        } finally {
            board.put(fromRow, fromCol, moving);
            board.put(toRow, toCol, captured);
        }
    }
}
