package MainGame;
import java.util.ArrayList;
import java.util.List;

public final class Rules {

    public enum Status { ONGOING, CHECK, CHECKMATE, STALEMATE }

    private static final int[][] KNIGHT_OFFSETS = {
        {-2, -1}, {-2, 1}, {-1, -2}, {-1, 2}, {1, -2}, {1, 2}, {2, -1}, {2, 1}
    };
    private static final int[][] KING_OFFSETS = {
        {-1, -1}, {-1, 0}, {-1, 1}, {0, -1}, {0, 1}, {1, -1}, {1, 0}, {1, 1}
    };
    private static final int[][] STRAIGHT_DIRECTIONS = {
        {-1, 0}, {1, 0}, {0, -1}, {0, 1}
    };
    private static final int[][] DIAGONAL_DIRECTIONS = {
        {-1, -1}, {-1, 1}, {1, -1}, {1, 1}
    };

    private static final int WHITE_PAWN_START_ROW = 6;
    private static final int BLACK_PAWN_START_ROW = 1;
    private static final int WHITE_HOME_ROW = 7;
    private static final int BLACK_HOME_ROW = 0;
    private static final int KING_START_COL = 4;
    private static final int QUEENSIDE_ROOK_COL = 0;
    private static final int KINGSIDE_ROOK_COL = 7;

    private Rules() {
    }

    // ---------- Legal moves ----------

    // Only moves that do not leave the mover's own king in check
    public static List<int[]> getValidMoves(Board board, int row, int col) {
        List<int[]> legal = new ArrayList<>();
        if (board.getPiece(row, col) == null) {
            return legal;
        }
        for (int[] target : getPseudoLegalMoves(board, row, col)) {
            if (!leavesKingInCheck(board, row, col, target[0], target[1])) {
                legal.add(target);
            }
        }
        return legal;
    }

    public static boolean isValidMove(Board board, int fromRow, int fromCol, int toRow, int toCol) {
        for (int[] target : getValidMoves(board, fromRow, fromCol)) {
            if (target[0] == toRow && target[1] == toCol) {
                return true;
            }
        }
        return false;
    }

    // ---------- Game state ----------

    public static Status getStatus(Board board, Piece.Side sideToMove) {
        boolean inCheck = isInCheck(board, sideToMove);
        if (hasAnyLegalMove(board, sideToMove)) {
            return inCheck ? Status.CHECK : Status.ONGOING;
        }
        return inCheck ? Status.CHECKMATE : Status.STALEMATE;
    }

    public static boolean isCheckmate(Board board, Piece.Side side) {
        return getStatus(board, side) == Status.CHECKMATE;
    }

    public static boolean isStalemate(Board board, Piece.Side side) {
        return getStatus(board, side) == Status.STALEMATE;
    }

    public static boolean isInCheck(Board board, Piece.Side side) {
        int[] king = findKing(board, side);
        return king != null && isSquareAttacked(board, king[0], king[1], side.opposite());
    }

    public static boolean hasAnyLegalMove(Board board, Piece.Side side) {
        for (int row = 0; row < Board.SIZE; row++) {
            for (int col = 0; col < Board.SIZE; col++) {
                Piece piece = board.getPiece(row, col);
                if (piece != null && piece.getSide() == side
                        && !getValidMoves(board, row, col).isEmpty()) {
                    return true;
                }
            }
        }
        return false;
    }

    public static int[] findKing(Board board, Piece.Side side) {
        for (int row = 0; row < Board.SIZE; row++) {
            for (int col = 0; col < Board.SIZE; col++) {
                if (isPieceOf(board, row, col, side, Piece.Type.KING)) {
                    return new int[]{row, col};
                }
            }
        }
        return null;
    }

    // Looks outward from the square instead of generating every enemy move,
    // so castling checks cannot recurse back into move generation
    public static boolean isSquareAttacked(Board board, int row, int col, Piece.Side attacker) {
        // A white pawn attacks upward (row - 1), so it sits one row below the square
        int pawnRow = attacker == Piece.Side.WHITE ? row + 1 : row - 1;
        if (isPieceOf(board, pawnRow, col - 1, attacker, Piece.Type.PAWN)
                || isPieceOf(board, pawnRow, col + 1, attacker, Piece.Type.PAWN)) {
            return true;
        }
        for (int[] offset : KNIGHT_OFFSETS) {
            if (isPieceOf(board, row + offset[0], col + offset[1], attacker, Piece.Type.KNIGHT)) {
                return true;
            }
        }
        for (int[] offset : KING_OFFSETS) {
            if (isPieceOf(board, row + offset[0], col + offset[1], attacker, Piece.Type.KING)) {
                return true;
            }
        }
        return isAttackedAlongLines(board, row, col, attacker, STRAIGHT_DIRECTIONS, Piece.Type.ROOK)
                || isAttackedAlongLines(board, row, col, attacker, DIAGONAL_DIRECTIONS, Piece.Type.BISHOP);
    }

    // ---------- Special move detection (Board uses these to execute the move) ----------

    public static boolean isCastlingMove(Board board, int fromRow, int fromCol, int toRow, int toCol) {
        Piece piece = board.getPiece(fromRow, fromCol);
        return piece != null && piece.getType() == Piece.Type.KING
                && fromRow == toRow && Math.abs(toCol - fromCol) == 2;
    }

    // {rookFromCol, rookToCol}; the rook lands on the square the king passed over
    public static int[] getCastlingRookCols(int kingFromCol, int kingToCol) {
        int rookFromCol = kingToCol > kingFromCol ? KINGSIDE_ROOK_COL : QUEENSIDE_ROOK_COL;
        return new int[]{rookFromCol, (kingFromCol + kingToCol) / 2};
    }

    public static boolean isEnPassantMove(Board board, int fromRow, int fromCol, int toRow, int toCol) {
        Piece piece = board.getPiece(fromRow, fromCol);
        int[] target = board.getEnPassantTarget();
        return piece != null && piece.getType() == Piece.Type.PAWN
                && fromCol != toCol && board.isEmpty(toRow, toCol)
                && target != null && target[0] == toRow && target[1] == toCol;
    }

    public static boolean isPromotionMove(Board board, int fromRow, int fromCol, int toRow) {
        Piece piece = board.getPiece(fromRow, fromCol);
        return piece != null && piece.getType() == Piece.Type.PAWN
                && toRow == (piece.isWhite() ? 0 : Board.SIZE - 1);
    }

    // ---------- Move generation ----------

    // Every move the piece could make if its own king's safety were ignored
    private static List<int[]> getPseudoLegalMoves(Board board, int row, int col) {
        List<int[]> moves = new ArrayList<>();
        Piece piece = board.getPiece(row, col);
        switch (piece.getType()) {
            case PAWN:
                addPawnMoves(board, piece, row, col, moves);
                break;
            case KNIGHT:
                addStepMoves(board, piece, row, col, KNIGHT_OFFSETS, moves);
                break;
            case BISHOP:
                addSlidingMoves(board, piece, row, col, DIAGONAL_DIRECTIONS, moves);
                break;
            case ROOK:
                addSlidingMoves(board, piece, row, col, STRAIGHT_DIRECTIONS, moves);
                break;
            case QUEEN:
                addSlidingMoves(board, piece, row, col, STRAIGHT_DIRECTIONS, moves);
                addSlidingMoves(board, piece, row, col, DIAGONAL_DIRECTIONS, moves);
                break;
            case KING:
                addStepMoves(board, piece, row, col, KING_OFFSETS, moves);
                addCastlingMoves(board, piece, row, col, moves);
                break;
            default:
                throw new IllegalStateException("Unknown piece type: " + piece.getType());
        }
        return moves;
    }

    private static void addPawnMoves(Board board, Piece pawn, int row, int col, List<int[]> moves) {
        int direction = pawn.isWhite() ? -1 : 1;
        int startRow = pawn.isWhite() ? WHITE_PAWN_START_ROW : BLACK_PAWN_START_ROW;
        int oneStepRow = row + direction;

        if (board.isEmpty(oneStepRow, col)) {
            moves.add(new int[]{oneStepRow, col});
            int twoStepRow = row + 2 * direction;
            if (row == startRow && board.isEmpty(twoStepRow, col)) {
                moves.add(new int[]{twoStepRow, col});
            }
        }

        for (int sideStep : new int[]{-1, 1}) {
            Piece target = board.getPiece(oneStepRow, col + sideStep);
            if (pawn.isEnemyOf(target)) {
                moves.add(new int[]{oneStepRow, col + sideStep});
            }
        }

        // En passant: the enemy pawn that just double-stepped sits beside us
        int[] passant = board.getEnPassantTarget();
        if (passant != null && passant[0] == oneStepRow && Math.abs(passant[1] - col) == 1
                && isPieceOf(board, row, passant[1], pawn.getSide().opposite(), Piece.Type.PAWN)) {
            moves.add(new int[]{passant[0], passant[1]});
        }
    }

    private static void addCastlingMoves(Board board, Piece king, int row, int col, List<int[]> moves) {
        int homeRow = king.isWhite() ? WHITE_HOME_ROW : BLACK_HOME_ROW;
        Piece.Side enemy = king.getSide().opposite();
        if (king.hasMoved() || row != homeRow || col != KING_START_COL
                || isSquareAttacked(board, row, col, enemy)) {
            return;
        }
        tryCastle(board, king, row, col, KINGSIDE_ROOK_COL, moves);
        tryCastle(board, king, row, col, QUEENSIDE_ROOK_COL, moves);
    }

    private static void tryCastle(Board board, Piece king, int row, int kingCol, int rookCol, List<int[]> moves) {
        Piece rook = board.getPiece(row, rookCol);
        if (rook == null || rook.getType() != Piece.Type.ROOK
                || rook.getSide() != king.getSide() || rook.hasMoved()) {
            return;
        }
        int step = rookCol > kingCol ? 1 : -1;
        for (int c = kingCol + step; c != rookCol; c += step) {
            if (!board.isEmpty(row, c)) {
                return;
            }
        }
        // King may not pass through or land on an attacked square
        Piece.Side enemy = king.getSide().opposite();
        if (isSquareAttacked(board, row, kingCol + step, enemy)
                || isSquareAttacked(board, row, kingCol + 2 * step, enemy)) {
            return;
        }
        moves.add(new int[]{row, kingCol + 2 * step});
    }

    // Knight and king: fixed jumps, blocked only by own pieces
    private static void addStepMoves(Board board, Piece piece, int row, int col,
                                     int[][] offsets, List<int[]> moves) {
        for (int[] offset : offsets) {
            int targetRow = row + offset[0];
            int targetCol = col + offset[1];
            if (isEmptyOrEnemy(board, piece, targetRow, targetCol)) {
                moves.add(new int[]{targetRow, targetCol});
            }
        }
    }

    // Bishop, rook, queen: travel until the edge, a blocker, or a capture
    private static void addSlidingMoves(Board board, Piece piece, int row, int col,
                                        int[][] directions, List<int[]> moves) {
        for (int[] direction : directions) {
            int targetRow = row + direction[0];
            int targetCol = col + direction[1];
            while (board.isInside(targetRow, targetCol)) {
                Piece occupant = board.getPiece(targetRow, targetCol);
                if (occupant == null) {
                    moves.add(new int[]{targetRow, targetCol});
                } else {
                    if (piece.isEnemyOf(occupant)) {
                        moves.add(new int[]{targetRow, targetCol});
                    }
                    break;
                }
                targetRow += direction[0];
                targetCol += direction[1];
            }
        }
    }

    // ---------- Helpers ----------

    // Plays the move on the real grid, tests the king, then restores everything
    private static boolean leavesKingInCheck(Board board, int fromRow, int fromCol, int toRow, int toCol) {
        Piece moving = board.getPiece(fromRow, fromCol);
        Piece captured = board.getPiece(toRow, toCol);
        boolean enPassant = isEnPassantMove(board, fromRow, fromCol, toRow, toCol);
        Piece passantVictim = enPassant ? board.getPiece(fromRow, toCol) : null;

        board.put(toRow, toCol, moving);
        board.put(fromRow, fromCol, null);
        if (enPassant) {
            board.put(fromRow, toCol, null);
        }
        try {
            return isInCheck(board, moving.getSide());
        } finally {
            board.put(fromRow, fromCol, moving);
            board.put(toRow, toCol, captured);
            if (enPassant) {
                board.put(fromRow, toCol, passantVictim);
            }
        }
    }

    // The queen attacks along both kinds of line, so it always counts
    private static boolean isAttackedAlongLines(Board board, int row, int col, Piece.Side attacker,
                                                int[][] directions, Piece.Type lineMover) {
        for (int[] direction : directions) {
            int r = row + direction[0];
            int c = col + direction[1];
            while (board.isInside(r, c)) {
                Piece occupant = board.getPiece(r, c);
                if (occupant != null) {
                    if (occupant.getSide() == attacker
                            && (occupant.getType() == lineMover || occupant.getType() == Piece.Type.QUEEN)) {
                        return true;
                    }
                    break;
                }
                r += direction[0];
                c += direction[1];
            }
        }
        return false;
    }

    private static boolean isPieceOf(Board board, int row, int col, Piece.Side side, Piece.Type type) {
        Piece piece = board.getPiece(row, col);
        return piece != null && piece.getSide() == side && piece.getType() == type;
    }

    private static boolean isEmptyOrEnemy(Board board, Piece piece, int row, int col) {
        if (!board.isInside(row, col)) {
            return false;
        }
        Piece occupant = board.getPiece(row, col);
        return occupant == null || piece.isEnemyOf(occupant);
    }
}
