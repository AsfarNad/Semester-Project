package MainGame;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class Board extends JPanel {

    public static final int SIZE = 8;

    private static final Color BACKGROUND = new Color(0x1C1B19);
    private static final Color FRAME = new Color(0x2E2A26);
    private static final Color SHADOW = new Color(0, 0, 0, 90);
    private static final Color LIGHT_SQUARE = new Color(0xF0D9B5);
    private static final Color DARK_SQUARE = new Color(0xB58863);
    private static final Color SELECTED_OVERLAY = new Color(20, 85, 30, 125);
    private static final Color LAST_MOVE_OVERLAY = new Color(155, 199, 0, 100);
    private static final Color MOVE_HINT = new Color(20, 85, 30, 110);
    private static final Color HOVER_TARGET_OVERLAY = new Color(20, 85, 30, 80);
    private static final Color CHECK_OVERLAY = new Color(220, 40, 40, 150);
    private static final Color LABEL_TEXT = new Color(0xBFB6AA);
    private static final Color STATUS_TEXT = new Color(0xEDE6DC);

    private static final Piece.Type[] BACK_RANK = {
        Piece.Type.ROOK, Piece.Type.KNIGHT, Piece.Type.BISHOP, Piece.Type.QUEEN,
        Piece.Type.KING, Piece.Type.BISHOP, Piece.Type.KNIGHT, Piece.Type.ROOK
    };
    private static final Piece.Type[] PROMOTION_CHOICES = {
        Piece.Type.QUEEN, Piece.Type.ROOK, Piece.Type.BISHOP, Piece.Type.KNIGHT
    };
    private static final int DRAG_THRESHOLD_PIXELS = 4;

    private final Piece[][] grid = new Piece[SIZE][SIZE];
    private Piece.Side sideToMove;
    private List<int[]> validTargets;
    // Squares are {row, col}; null means none
    private int[] selected, hover, lastMoveFrom, lastMoveTo;
    // Square a pawn skipped over on the previous move; only valid for one turn
    private int[] enPassantTarget;
    private Rules.Status status = Rules.Status.ONGOING;
    // dragPoint != null means a drag is in progress
    private Point pressPoint, dragPoint;

    // Recomputed on every paint so the board scales with the window
    private int squareSize, boardX, boardY, margin;

    public Board() {
        setBackground(BACKGROUND);
        setPreferredSize(new Dimension(720, 720));
        setupPieces();
        MouseAdapter mouseHandler = new BoardMouseHandler();
        addMouseListener(mouseHandler);
        addMouseMotionListener(mouseHandler);
    }

    public final void setupPieces() {
        for (Piece[] row : grid) Arrays.fill(row, null);
        for (int col = 0; col < SIZE; col++) {
            grid[0][col] = new Piece(BACK_RANK[col], Piece.Side.BLACK);
            grid[1][col] = new Piece(Piece.Type.PAWN, Piece.Side.BLACK);
            grid[6][col] = new Piece(Piece.Type.PAWN, Piece.Side.WHITE);
            grid[7][col] = new Piece(BACK_RANK[col], Piece.Side.WHITE);
        }
        sideToMove = Piece.Side.WHITE;
        lastMoveFrom = lastMoveTo = enPassantTarget = null;
        status = Rules.Status.ONGOING;
        clearSelection();
        repaint();
    }

    public boolean isInside(int row, int col) {
        return row >= 0 && row < SIZE && col >= 0 && col < SIZE;
    }

    public Piece getPiece(int row, int col) {
        return isInside(row, col) ? grid[row][col] : null;
    }

    public void setPiece(int row, int col, Piece piece) {
        if (isInside(row, col)) {
            grid[row][col] = piece;
            repaint();
        }
    }

    // Raw write used by Rules to test moves; no repaint
    void put(int row, int col, Piece piece) {
        if (isInside(row, col)) grid[row][col] = piece;
    }

    public boolean isEmpty(int row, int col) {
        return isInside(row, col) && grid[row][col] == null;
    }

    public Piece.Side getSideToMove() {
        return sideToMove;
    }

    public int[] getEnPassantTarget() {
        return enPassantTarget == null ? null : enPassantTarget.clone();
    }

    public Rules.Status getStatus() {
        return status;
    }

    public boolean isGameOver() {
        return status == Rules.Status.CHECKMATE || status == Rules.Status.STALEMATE;
    }

    // Returns false and changes nothing if Rules does not allow the move
    public boolean movePiece(int fromRow, int fromCol, int toRow, int toCol) {
        Piece moving = getPiece(fromRow, fromCol);
        if (isGameOver() || moving == null || moving.getSide() != sideToMove
                || !moving.canMoveTo(this, fromRow, fromCol, toRow, toCol)) {
            return false;
        }
        // Detect special moves before the grid changes
        boolean castling = Rules.isCastlingMove(this, fromRow, fromCol, toRow, toCol);
        boolean enPassant = Rules.isEnPassantMove(this, fromRow, fromCol, toRow, toCol);
        boolean doubleStep = moving.getType() == Piece.Type.PAWN && Math.abs(toRow - fromRow) == 2;
        Piece.Type promoteTo = Rules.isPromotionMove(this, fromRow, fromCol, toRow)
                ? askPromotionType() : null;

        grid[toRow][toCol] = moving;
        grid[fromRow][fromCol] = null;
        moving.markMoved();

        if (enPassant) {
            grid[fromRow][toCol] = null;
        }
        if (castling) {
            int[] rookCols = Rules.getCastlingRookCols(fromCol, toCol);
            Piece rook = grid[fromRow][rookCols[0]];
            grid[fromRow][rookCols[1]] = rook;
            grid[fromRow][rookCols[0]] = null;
            rook.markMoved();
        }
        if (promoteTo != null) {
            Piece promoted = new Piece(promoteTo, moving.getSide());
            promoted.markMoved();
            grid[toRow][toCol] = promoted;
        }

        enPassantTarget = doubleStep ? new int[]{(fromRow + toRow) / 2, fromCol} : null;
        lastMoveFrom = new int[]{fromRow, fromCol};
        lastMoveTo = new int[]{toRow, toCol};
        sideToMove = sideToMove.opposite();
        status = Rules.getStatus(this, sideToMove);
        clearSelection();
        repaint();
        if (isGameOver()) {
            // Let the final position paint before the modal dialog opens
            SwingUtilities.invokeLater(this::announceResult);
        }
        return true;
    }

    private Piece.Type askPromotionType() {
        String[] labels = {"Queen", "Rook", "Bishop", "Knight"};
        int choice = JOptionPane.showOptionDialog(this, "Promote pawn to:", "Pawn Promotion",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, labels, labels[0]);
        return choice >= 0 ? PROMOTION_CHOICES[choice] : Piece.Type.QUEEN; // closed dialog = queen
    }

    private void announceResult() {
        JOptionPane.showMessageDialog(this, resultText(), "Game Over", JOptionPane.INFORMATION_MESSAGE);
    }

    private String resultText() {
        if (status == Rules.Status.CHECKMATE) {
            return "Checkmate! " + sideName(sideToMove.opposite()) + " wins.";
        }
        return "Stalemate! The game is a draw.";
    }

    private static String sideName(Piece.Side side) {
        return side == Piece.Side.WHITE ? "White" : "Black";
    }

    private void select(int[] square) {
        selected = square;
        validTargets = grid[square[0]][square[1]].getValidMoves(this, square[0], square[1]);
        repaint();
    }

    private void clearSelection() {
        selected = null;
        validTargets = new ArrayList<>();
        pressPoint = dragPoint = null;
    }

    private static boolean sameSquare(int[] a, int[] b) {
        return a != null && b != null && a[0] == b[0] && a[1] == b[1];
    }

    // validTargets is only non-empty while a piece is selected
    private boolean isValidTarget(int[] square) {
        return validTargets.stream().anyMatch(target -> sameSquare(target, square));
    }

    private boolean isOwnPiece(int[] square) {
        if (isGameOver()) return false;
        Piece piece = square == null ? null : getPiece(square[0], square[1]);
        return piece != null && piece.getSide() == sideToMove;
    }

    private void computeLayout() {
        // 8 squares plus half a square of frame on each side
        squareSize = (int) Math.max(1, Math.min(getWidth(), getHeight()) / (SIZE + 1.0));
        margin = squareSize / 2;
        boardX = (getWidth() - squareSize * SIZE) / 2;
        boardY = (getHeight() - squareSize * SIZE) / 2;
    }

    private int[] squareAt(Point point) {
        if (point == null || squareSize <= 0) return null;
        int col = Math.floorDiv(point.x - boardX, squareSize);
        int row = Math.floorDiv(point.y - boardY, squareSize);
        return isInside(row, col) ? new int[]{row, col} : null;
    }

    private int squareX(int col) {
        return boardX + col * squareSize;
    }

    private int squareY(int row) {
        return boardY + row * squareSize;
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            computeLayout();
            paintFrame(g);
            paintSquares(g);
            paintPieces(g);
            paintMoveHints(g);
            paintCoordinates(g);
            paintStatus(g);
            paintDraggedPiece(g);
        } finally {
            g.dispose();
        }
    }

    private void paintFrame(Graphics2D g) {
        int x = boardX - margin, y = boardY - margin;
        int size = squareSize * SIZE + 2 * margin, arc = margin / 2;
        g.setColor(SHADOW);
        g.fillRoundRect(x + 4, y + 6, size, size, arc, arc);
        g.setColor(FRAME);
        g.fillRoundRect(x, y, size, size, arc, arc);
    }

    private void paintSquares(Graphics2D g) {
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                g.setColor((row + col) % 2 == 0 ? LIGHT_SQUARE : DARK_SQUARE);
                g.fillRect(squareX(col), squareY(row), squareSize, squareSize);
            }
        }
        fillSquare(g, lastMoveFrom, LAST_MOVE_OVERLAY);
        fillSquare(g, lastMoveTo, LAST_MOVE_OVERLAY);
        if (status == Rules.Status.CHECK || status == Rules.Status.CHECKMATE) {
            fillSquare(g, Rules.findKing(this, sideToMove), CHECK_OVERLAY);
        }
        fillSquare(g, selected, SELECTED_OVERLAY);
        if (isValidTarget(hover)) fillSquare(g, hover, HOVER_TARGET_OVERLAY);
    }

    private void fillSquare(Graphics2D g, int[] square, Color color) {
        if (square == null) return;
        g.setColor(color);
        g.fillRect(squareX(square[1]), squareY(square[0]), squareSize, squareSize);
    }

    private void paintPieces(Graphics2D g) {
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                boolean beingDragged = dragPoint != null && row == selected[0] && col == selected[1];
                if (grid[row][col] != null && !beingDragged) {
                    grid[row][col].draw(g, squareX(col), squareY(row), squareSize);
                }
            }
        }
    }

    private void paintMoveHints(Graphics2D g) {
        float stroke = squareSize * 0.08f;
        int inset = Math.round(stroke / 2) + 1;
        int dot = Math.round(squareSize * 0.30f);
        g.setColor(MOVE_HINT);
        g.setStroke(new BasicStroke(stroke));
        for (int[] target : validTargets) {
            if (sameSquare(target, hover)) continue;
            int x = squareX(target[1]), y = squareY(target[0]);
            if (grid[target[0]][target[1]] == null) {
                g.fillOval(x + (squareSize - dot) / 2, y + (squareSize - dot) / 2, dot, dot);
            } else {
                g.drawOval(x + inset, y + inset, squareSize - 2 * inset, squareSize - 2 * inset);
            }
        }
    }

    private void paintCoordinates(Graphics2D g) {
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, Math.max(9, Math.round(squareSize * 0.2f))));
        FontMetrics metrics = g.getFontMetrics();
        int textHeight = metrics.getAscent() - metrics.getDescent();
        int fileBaseline = boardY + squareSize * SIZE + (margin + textHeight) / 2;
        g.setColor(LABEL_TEXT);
        for (int i = 0; i < SIZE; i++) {
            String file = String.valueOf((char) ('a' + i));
            String rank = String.valueOf(SIZE - i);
            g.drawString(file, squareX(i) + (squareSize - metrics.stringWidth(file)) / 2, fileBaseline);
            g.drawString(rank, boardX - (margin + metrics.stringWidth(rank)) / 2, squareY(i) + (squareSize + textHeight) / 2);
        }
    }

    private void paintStatus(Graphics2D g) {
        // After checkmate the dot shows the winner; otherwise the side to move
        Piece.Side shown = status == Rules.Status.CHECKMATE ? sideToMove.opposite() : sideToMove;
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, Math.max(10, Math.round(squareSize * 0.22f))));
        FontMetrics metrics = g.getFontMetrics();
        int dot = metrics.getAscent() - metrics.getDescent();
        int baseline = boardY - (margin - dot) / 2;

        g.setColor(shown == Piece.Side.WHITE ? Color.WHITE : Color.BLACK);
        g.fillOval(boardX, baseline - dot, dot, dot);
        g.setColor(LABEL_TEXT);
        g.setStroke(new BasicStroke(1.2f));
        g.drawOval(boardX, baseline - dot, dot, dot);
        g.setColor(STATUS_TEXT);
        g.drawString(statusText(), boardX + dot + dot / 2, baseline);
    }

    private String statusText() {
        switch (status) {
            case CHECKMATE:
            case STALEMATE:
                return resultText();
            case CHECK:
                return sideName(sideToMove) + " to move - Check!";
            default:
                return sideName(sideToMove) + " to move";
        }
    }

    private void paintDraggedPiece(Graphics2D g) {
        if (dragPoint == null) return;
        int size = Math.round(squareSize * 1.1f);
        grid[selected[0]][selected[1]].draw(g, dragPoint.x - size / 2, dragPoint.y - size / 2, size);
    }

    private void updateHover(Point point) {
        int[] square = squareAt(point);
        if (!Arrays.equals(square, hover)) {
            hover = square;
            repaint();
        }
    }

    private class BoardMouseHandler extends MouseAdapter {

        @Override
        public void mousePressed(MouseEvent e) {
            boolean right = SwingUtilities.isRightMouseButton(e);
            if (isGameOver() || (!right && !SwingUtilities.isLeftMouseButton(e))) return;
            int[] square = right ? null : squareAt(e.getPoint());
            if (isValidTarget(square)) {
                movePiece(selected[0], selected[1], square[0], square[1]);
            } else if (isOwnPiece(square)) {
                select(square);
                pressPoint = e.getPoint();
            } else {
                clearSelection();
                repaint();
            }
        }

        @Override
        public void mouseDragged(MouseEvent e) {
            if (pressPoint == null
                    || (dragPoint == null && pressPoint.distance(e.getPoint()) <= DRAG_THRESHOLD_PIXELS)) {
                return;
            }
            dragPoint = e.getPoint();
            updateHover(dragPoint);
            repaint();
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            pressPoint = null;
            if (dragPoint == null) return;
            dragPoint = null;
            int[] square = squareAt(e.getPoint());
            if (isValidTarget(square)) {
                movePiece(selected[0], selected[1], square[0], square[1]);
            } else {
                repaint(); // dropped somewhere invalid: piece snaps back, stays selected
            }
        }

        @Override
        public void mouseMoved(MouseEvent e) {
            updateHover(e.getPoint());
            boolean clickable = isOwnPiece(hover) || isValidTarget(hover);
            setCursor(Cursor.getPredefinedCursor(clickable ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
        }

        @Override
        public void mouseExited(MouseEvent e) {
            if (dragPoint == null) updateHover(null);
        }
    }
}