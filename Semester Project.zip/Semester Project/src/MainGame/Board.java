package MainGame;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class Board extends JPanel {

    public static final int SIZE = 8;
    private static final int SQUARE = 75;

    private static final Color LIGHT_SQUARE = new Color(0xF0D9B5);
    private static final Color DARK_SQUARE = new Color(0xB58863);
    private static final Color SELECTED_OVERLAY = new Color(20, 85, 30, 125);
    private static final Color MOVE_HINT = new Color(20, 85, 30, 110);
    private static final Color CHECK_OVERLAY = new Color(220, 40, 40, 150);

    private static final Piece.Type[] BACK_RANK = {
        Piece.Type.ROOK, Piece.Type.KNIGHT, Piece.Type.BISHOP, Piece.Type.QUEEN,
        Piece.Type.KING, Piece.Type.BISHOP, Piece.Type.KNIGHT, Piece.Type.ROOK
    };

    private final Piece[][] grid = new Piece[SIZE][SIZE];
    private Piece.Side sideToMove = Piece.Side.WHITE;
    private Rules.Status status = Rules.Status.ONGOING;
    private int[] selected; // {row, col}, null when nothing is selected
    private List<int[]> validTargets = new ArrayList<>();

    public Board() {
        setPreferredSize(new Dimension(SIZE * SQUARE, SIZE * SQUARE));
        for (int col = 0; col < SIZE; col++) {
            grid[0][col] = new Piece(BACK_RANK[col], Piece.Side.BLACK);
            grid[1][col] = new Piece(Piece.Type.PAWN, Piece.Side.BLACK);
            grid[6][col] = new Piece(Piece.Type.PAWN, Piece.Side.WHITE);
            grid[7][col] = new Piece(BACK_RANK[col], Piece.Side.WHITE);
        }
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                handleClick(e.getY() / SQUARE, e.getX() / SQUARE);
            }
        });
    }

    public boolean isInside(int row, int col) {
        return row >= 0 && row < SIZE && col >= 0 && col < SIZE;
    }

    public Piece getPiece(int row, int col) {
        return isInside(row, col) ? grid[row][col] : null;
    }

    public boolean isEmpty(int row, int col) {
        return isInside(row, col) && grid[row][col] == null;
    }

    // Raw write used by Rules to test moves; no repaint
    void put(int row, int col, Piece piece) {
        grid[row][col] = piece;
    }

    private boolean isGameOver() {
        return status == Rules.Status.CHECKMATE || status == Rules.Status.STALEMATE;
    }

    // First click selects one of your pieces, second click on a highlighted square moves it
    private void handleClick(int row, int col) {
        if (isGameOver() || !isInside(row, col)) {
            return;
        }
        if (selected != null && isValidTarget(row, col)) {
            movePiece(selected[0], selected[1], row, col);
            return;
        }
        Piece piece = grid[row][col];
        if (piece != null && piece.getSide() == sideToMove) {
            selected = new int[]{row, col};
            validTargets = Rules.getValidMoves(this, row, col);
        } else {
            selected = null;
            validTargets = new ArrayList<>();
        }
        repaint();
    }

    private boolean isValidTarget(int row, int col) {
        for (int[] target : validTargets) {
            if (target[0] == row && target[1] == col) {
                return true;
            }
        }
        return false;
    }

    private void movePiece(int fromRow, int fromCol, int toRow, int toCol) {
        Piece moving = grid[fromRow][fromCol];
        grid[toRow][toCol] = moving;
        grid[fromRow][fromCol] = null;

        // A pawn reaching the last row always becomes a queen
        if (moving.getType() == Piece.Type.PAWN && (toRow == 0 || toRow == SIZE - 1)) {
            grid[toRow][toCol] = new Piece(Piece.Type.QUEEN, moving.getSide());
        }

        sideToMove = sideToMove.opposite();
        status = Rules.getStatus(this, sideToMove);
        selected = null;
        validTargets = new ArrayList<>();
        repaint();
        if (isGameOver()) {
            // Let the final position paint before the dialog opens
            SwingUtilities.invokeLater(this::announceResult);
        }
    }

    private void announceResult() {
        String winner = sideToMove == Piece.Side.WHITE ? "Black" : "White";
        String text = status == Rules.Status.CHECKMATE
                ? "Checkmate! " + winner + " wins."
                : "Stalemate! The game is a draw.";
        JOptionPane.showMessageDialog(this, text, "Game Over", JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                g.setColor((row + col) % 2 == 0 ? LIGHT_SQUARE : DARK_SQUARE);
                g.fillRect(col * SQUARE, row * SQUARE, SQUARE, SQUARE);
            }
        }
        if (status == Rules.Status.CHECK || status == Rules.Status.CHECKMATE) {
            fillSquare(g, Rules.findKing(this, sideToMove), CHECK_OVERLAY);
        }
        fillSquare(g, selected, SELECTED_OVERLAY);

        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                if (grid[row][col] != null) {
                    grid[row][col].draw(g, col * SQUARE, row * SQUARE, SQUARE);
                }
            }
        }

        // Dot on empty squares, ring around capturable pieces
        g.setColor(MOVE_HINT);
        g.setStroke(new BasicStroke(6));
        for (int[] target : validTargets) {
            int x = target[1] * SQUARE, y = target[0] * SQUARE;
            if (grid[target[0]][target[1]] == null) {
                g.fillOval(x + SQUARE / 2 - 11, y + SQUARE / 2 - 11, 22, 22);
            } else {
                g.drawOval(x + 4, y + 4, SQUARE - 8, SQUARE - 8);
            }
        }
    }

    private void fillSquare(Graphics2D g, int[] square, Color color) {
        if (square != null) {
            g.setColor(color);
            g.fillRect(square[1] * SQUARE, square[0] * SQUARE, SQUARE, SQUARE);
        }
    }
}
