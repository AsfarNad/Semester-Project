package MainGame;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;

public class Piece {

    public enum Side {
        WHITE, BLACK;

        public Side opposite() {
            return this == WHITE ? BLACK : WHITE;
        }
    }

    public enum Type {
        KING('K'), QUEEN('Q'), ROOK('R'), BISHOP('B'), KNIGHT('N'), PAWN('P');

        private final char code;

        Type(char code) {
            this.code = code;
        }
    }

    private static final Map<String, BufferedImage> IMAGES = new HashMap<>();

    private final Type type;
    private final Side side;
    private boolean hasMoved = false;

    public Piece(Type type, Side side) {
        this.type = type;
        this.side = side;
    }

    public Type getType() {
        return type;
    }

    public Side getSide() {
        return side;
    }

    public boolean isWhite() {
        return side == Side.WHITE;
    }

    public boolean hasMoved() {
        return hasMoved;
    }

    public void markMoved() {
        hasMoved = true;
    }

    public boolean isEnemyOf(Piece other) {
        return other != null && other.side != side;
    }

    public static void preloadImages() {
        for (String color : new String[]{"w", "b"}) {
            for (Type type : Type.values()) {
                loadImage(color + type.code + ".png");
            }
        }
    }

    // Draws the image centered in the square
    public void draw(Graphics2D g, int x, int y, int squareSize) {
        BufferedImage image = loadImage((isWhite() ? "w" : "b") + type.code + ".png");
        if (image != null) {
            g.drawImage(image, x + (squareSize - image.getWidth()) / 2,
                    y + (squareSize - image.getHeight()) / 2, null);
        }
    }
    
    private static synchronized BufferedImage loadImage(String fileName) {
        if (!IMAGES.containsKey(fileName)) {
            BufferedImage image = null;
            try {
                image = ImageIO.read(new File("images", fileName));
            } catch (IOException e) {
                System.err.println("Could not load piece image " + fileName + ": " + e.getMessage());
            }
            IMAGES.put(fileName, image);
        }
        return IMAGES.get(fileName);
    }
}
