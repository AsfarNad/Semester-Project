package MainGame;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;

public class Piece {

    public enum Side {
        WHITE, BLACK;

        public Side opposite() {
            return this == WHITE ? BLACK : WHITE;
        }
    }

    // The letter matches the image names in the images/ folder, e.g. wK.png
    public enum Type {
        KING('K'), QUEEN('Q'), ROOK('R'), BISHOP('B'), KNIGHT('N'), PAWN('P');

        private final char code;

        Type(char code) {
            this.code = code;
        }
    }

    // Each image is read from disk once, then reused
    private static final Map<String, BufferedImage> IMAGES = new HashMap<>();

    private final Type type;
    private final Side side;

    public Piece(Type type, Side side) {
        this.type = type;
        this.side = side;
    }

    public Type getType() {
        return type;
    }

    public Side getSide() {
        return side;
    }

    public boolean isWhite() {
        return side == Side.WHITE;
    }

    public boolean isEnemyOf(Piece other) {
        return other != null && other.side != side;
    }

    // Draws the image centered in the square
    public void draw(Graphics2D g, int x, int y, int squareSize) {
        BufferedImage image = loadImage((isWhite() ? "w" : "b") + type.code + ".png");
        if (image != null) {
            g.drawImage(image, x + (squareSize - image.getWidth()) / 2,
                    y + (squareSize - image.getHeight()) / 2, null);
        }
    }

    // Path is relative to the project folder, which is where NetBeans runs the app
    private static BufferedImage loadImage(String fileName) {
        if (!IMAGES.containsKey(fileName)) {
            BufferedImage image = null;
            try {
                image = ImageIO.read(new File("images", fileName));
            } catch (IOException e) {
                System.err.println("Could not load piece image " + fileName + ": " + e.getMessage());
            }
            IMAGES.put(fileName, image);
        }
        return IMAGES.get(fileName);
    }
}
