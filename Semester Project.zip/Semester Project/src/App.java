import MainGame.Piece;
import javax.swing.SwingUtilities;

public class App {

    public static void main(String[] args) {
        // THREAD: load the piece images in the background while the login window opens,
        // so the first game board appears without a delay
        Thread preloader = new Thread(Piece::preloadImages, "image-preloader");
        preloader.setDaemon(true);
        preloader.start();

        SwingUtilities.invokeLater(
                () -> new LoginFrame(new UserStore())
        );
    }
}
