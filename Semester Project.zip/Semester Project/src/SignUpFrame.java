import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;

public class SignUpFrame implements ActionListener {

    private static final int WIDTH = 440;
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*\\.[A-Za-z]{2,}$");

    private final JFrame frame = ChessUI.frame("Sign Up", WIDTH, 560);
    private final JTextField userField = new JTextField();
    private final JTextField emailField = new JTextField();
    private final JPasswordField passField = new JPasswordField();
    private final JPasswordField confirmField = new JPasswordField();
    private final JButton signUpButton = new JButton("Sign Up");
    private final JButton backButton = new JButton("Back");
    private final JLabel messageLabel = new JLabel("", SwingConstants.CENTER);
    private final UserStore store;

    public SignUpFrame(UserStore store) {
        this.store = store;

        JLabel title = ChessUI.title("♛  Join the Board", WIDTH);
        JComponent backRank = ChessUI.ornament(ChessUI.BACK_RANK, true, WIDTH, 88);
        JComponent pawns = ChessUI.ornament(ChessUI.PAWNS, false, WIDTH, 494);

        JLabel userLabel = ChessUI.label("Username");
        JLabel emailLabel = ChessUI.label("Email");
        JLabel passLabel = ChessUI.label("Password");
        JLabel confirmLabel = ChessUI.label("Confirm password");

        userLabel.setBounds(70, 124, 300, 20);
        userField.setBounds(70, 146, 300, 36);
        emailLabel.setBounds(70, 192, 300, 20);
        emailField.setBounds(70, 214, 300, 36);
        passLabel.setBounds(70, 260, 300, 20);
        passField.setBounds(70, 282, 300, 36);
        confirmLabel.setBounds(70, 328, 300, 20);
        confirmField.setBounds(70, 350, 300, 36);
        signUpButton.setBounds(70, 404, 145, 38);
        backButton.setBounds(225, 404, 145, 38);
        messageLabel.setBounds(30, 452, 380, 24);
        messageLabel.setFont(new Font("SansSerif", Font.BOLD, 13));

        ChessUI.style(userField);
        ChessUI.style(emailField);
        ChessUI.style(passField);
        ChessUI.style(confirmField);
        ChessUI.style(signUpButton, true);
        ChessUI.style(backButton, false);

        signUpButton.addActionListener(this);
        backButton.addActionListener(this);
        confirmField.addActionListener(this); // press Enter to sign up

        ChessUI.add(frame, title, backRank, userLabel, userField, emailLabel, emailField,
                passLabel, passField, confirmLabel, confirmField, signUpButton, backButton,
                messageLabel, pawns);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == backButton) {
            frame.dispose();
            new LoginFrame(store);
            return;
        }

        String username = userField.getText().trim();
        String email = emailField.getText().trim().toLowerCase();
        String password = new String(passField.getPassword());
        String confirm = new String(confirmField.getPassword());

        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || confirm.isEmpty()) {
            showError("Please fill in all fields");
        } else if (username.length() < 3) {
            showError("Username must be at least 3 characters");
        } else if (username.contains(",") || username.contains(" ")) {
            showError("Username cannot contain spaces or commas");
        } else if (email.length() > 254 || !EMAIL_PATTERN.matcher(email).matches()) {
            showError("Please enter a valid email address");
        } else if (password.length() < 6) {
            showError("Password must be at least 6 characters");
        } else if (!password.equals(confirm)) {
            showError("Passwords do not match");
        } else if (store.userExists(username)) {
            showError("Username is already taken");
        } else if (store.emailExists(email)) {
            showError("An account with this email already exists");
        } else if (!store.register(username, email, password)) {
            showError("Could not save the account");
        } else {
            JOptionPane.showMessageDialog(frame, "Account created. You can log in now.");
            frame.dispose();
            new LoginFrame(store);
        }
    }

    private void showError(String text) {
        messageLabel.setForeground(ChessUI.ERROR);
        messageLabel.setText(text);
    }
}