// Sign-up rules for usernames and passwords.
// Each method returns an error message, or null when the value is acceptable.
public final class Credentials {

    // Anything printable that is not a letter, digit or space
    private static final String SPECIAL_CHARACTERS = "!@#$%^&*()_+-=[]{};':\"\\|,.<>/?`~";

    private Credentials() {
    }

    public static String checkUsername(String username) {
        if (username.length() < 3) {
            return "Username must be at least 3 characters";
        }
        if (containsSpace(username)) {
            return "Username cannot contain spaces";
        }
        if (!containsSpecial(username)) {
            return "Username needs a special character (e.g. _ . ! @ #)";
        }
        return null;
    }

    public static String checkPassword(String password) {
        if (password.length() < 6) {
            return "Password must be at least 6 characters";
        }
        if (containsSpace(password)) {
            return "Password cannot contain spaces";
        }
        if (!containsSpecial(password)) {
            return "Password needs a special character (e.g. ! @ # $ %)";
        }
        return null;
    }

    private static boolean containsSpecial(String text) {
        for (char c : text.toCharArray()) {
            if (SPECIAL_CHARACTERS.indexOf(c) >= 0) {
                return true;
            }
        }
        return false;
    }

    private static boolean containsSpace(String text) {
        for (char c : text.toCharArray()) {
            if (Character.isWhitespace(c)) {
                return true;
            }
        }
        return false;
    }
}
